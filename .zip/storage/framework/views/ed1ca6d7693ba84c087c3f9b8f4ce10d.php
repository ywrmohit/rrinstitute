<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RR Institute - Computer Courses & Visa Services</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="bg-gray-50 text-gray-800 antialiased">

    <!-- Announcement Bar -->
    <?php if (isset($component)) { $__componentOriginal0c8ef625e8265a4afd8570b9540f6b64 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0c8ef625e8265a4afd8570b9540f6b64 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.announcement-bar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('announcement-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0c8ef625e8265a4afd8570b9540f6b64)): ?>
<?php $attributes = $__attributesOriginal0c8ef625e8265a4afd8570b9540f6b64; ?>
<?php unset($__attributesOriginal0c8ef625e8265a4afd8570b9540f6b64); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0c8ef625e8265a4afd8570b9540f6b64)): ?>
<?php $component = $__componentOriginal0c8ef625e8265a4afd8570b9540f6b64; ?>
<?php unset($__componentOriginal0c8ef625e8265a4afd8570b9540f6b64); ?>
<?php endif; ?>

    <!-- Navbar -->

    <?php if (isset($component)) { $__componentOriginala591787d01fe92c5706972626cdf7231 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala591787d01fe92c5706972626cdf7231 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala591787d01fe92c5706972626cdf7231)): ?>
<?php $attributes = $__attributesOriginala591787d01fe92c5706972626cdf7231; ?>
<?php unset($__attributesOriginala591787d01fe92c5706972626cdf7231); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala591787d01fe92c5706972626cdf7231)): ?>
<?php $component = $__componentOriginala591787d01fe92c5706972626cdf7231; ?>
<?php unset($__componentOriginala591787d01fe92c5706972626cdf7231); ?>
<?php endif; ?>

    <!-- Hero Section -->

    <?php if (isset($component)) { $__componentOriginal04f02f1e0f152287a127192de01fe241 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal04f02f1e0f152287a127192de01fe241 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.hero','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('hero'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal04f02f1e0f152287a127192de01fe241)): ?>
<?php $attributes = $__attributesOriginal04f02f1e0f152287a127192de01fe241; ?>
<?php unset($__attributesOriginal04f02f1e0f152287a127192de01fe241); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal04f02f1e0f152287a127192de01fe241)): ?>
<?php $component = $__componentOriginal04f02f1e0f152287a127192de01fe241; ?>
<?php unset($__componentOriginal04f02f1e0f152287a127192de01fe241); ?>
<?php endif; ?>

    <!-- Features Section (Why Choose Us) -->

    <?php if (isset($component)) { $__componentOriginalf67dc3bc3f984190149e50f478986108 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf67dc3bc3f984190149e50f478986108 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.features','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('features'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf67dc3bc3f984190149e50f478986108)): ?>
<?php $attributes = $__attributesOriginalf67dc3bc3f984190149e50f478986108; ?>
<?php unset($__attributesOriginalf67dc3bc3f984190149e50f478986108); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf67dc3bc3f984190149e50f478986108)): ?>
<?php $component = $__componentOriginalf67dc3bc3f984190149e50f478986108; ?>
<?php unset($__componentOriginalf67dc3bc3f984190149e50f478986108); ?>
<?php endif; ?>

    <!-- Popular Courses Section -->

    <?php if (isset($component)) { $__componentOriginal2fbb42b66b7162918961cdb6db382691 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2fbb42b66b7162918961cdb6db382691 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.courses','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('courses'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2fbb42b66b7162918961cdb6db382691)): ?>
<?php $attributes = $__attributesOriginal2fbb42b66b7162918961cdb6db382691; ?>
<?php unset($__attributesOriginal2fbb42b66b7162918961cdb6db382691); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2fbb42b66b7162918961cdb6db382691)): ?>
<?php $component = $__componentOriginal2fbb42b66b7162918961cdb6db382691; ?>
<?php unset($__componentOriginal2fbb42b66b7162918961cdb6db382691); ?>
<?php endif; ?>
    <!-- Visa Services Overview Section -->

    <?php if (isset($component)) { $__componentOriginal652872fcf24e295712b79bf0d40c1b51 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal652872fcf24e295712b79bf0d40c1b51 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.visa-services','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('visa-services'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal652872fcf24e295712b79bf0d40c1b51)): ?>
<?php $attributes = $__attributesOriginal652872fcf24e295712b79bf0d40c1b51; ?>
<?php unset($__attributesOriginal652872fcf24e295712b79bf0d40c1b51); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal652872fcf24e295712b79bf0d40c1b51)): ?>
<?php $component = $__componentOriginal652872fcf24e295712b79bf0d40c1b51; ?>
<?php unset($__componentOriginal652872fcf24e295712b79bf0d40c1b51); ?>
<?php endif; ?>

    <!-- Stats Section -->

    <?php if (isset($component)) { $__componentOriginalda50c8a736c70542f601e56d53889e42 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda50c8a736c70542f601e56d53889e42 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.stats','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('stats'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda50c8a736c70542f601e56d53889e42)): ?>
<?php $attributes = $__attributesOriginalda50c8a736c70542f601e56d53889e42; ?>
<?php unset($__attributesOriginalda50c8a736c70542f601e56d53889e42); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda50c8a736c70542f601e56d53889e42)): ?>
<?php $component = $__componentOriginalda50c8a736c70542f601e56d53889e42; ?>
<?php unset($__componentOriginalda50c8a736c70542f601e56d53889e42); ?>
<?php endif; ?>
    <!-- About Us Section -->

    <?php if (isset($component)) { $__componentOriginalff6de83cb070587833d4f86022c57961 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalff6de83cb070587833d4f86022c57961 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.about','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('about'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalff6de83cb070587833d4f86022c57961)): ?>
<?php $attributes = $__attributesOriginalff6de83cb070587833d4f86022c57961; ?>
<?php unset($__attributesOriginalff6de83cb070587833d4f86022c57961); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalff6de83cb070587833d4f86022c57961)): ?>
<?php $component = $__componentOriginalff6de83cb070587833d4f86022c57961; ?>
<?php unset($__componentOriginalff6de83cb070587833d4f86022c57961); ?>
<?php endif; ?>
    
    <!-- Reviews Section -->
    <?php if (isset($component)) { $__componentOriginale1fc0cbaf997812f2d1cd6fe257968db = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale1fc0cbaf997812f2d1cd6fe257968db = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.reviews','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('reviews'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale1fc0cbaf997812f2d1cd6fe257968db)): ?>
<?php $attributes = $__attributesOriginale1fc0cbaf997812f2d1cd6fe257968db; ?>
<?php unset($__attributesOriginale1fc0cbaf997812f2d1cd6fe257968db); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale1fc0cbaf997812f2d1cd6fe257968db)): ?>
<?php $component = $__componentOriginale1fc0cbaf997812f2d1cd6fe257968db; ?>
<?php unset($__componentOriginale1fc0cbaf997812f2d1cd6fe257968db); ?>
<?php endif; ?>

    <!-- FAQ Section -->
    <?php if (isset($component)) { $__componentOriginalc457016352c9443b6633e7dc1fd2d1f7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc457016352c9443b6633e7dc1fd2d1f7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.faq','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('faq'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc457016352c9443b6633e7dc1fd2d1f7)): ?>
<?php $attributes = $__attributesOriginalc457016352c9443b6633e7dc1fd2d1f7; ?>
<?php unset($__attributesOriginalc457016352c9443b6633e7dc1fd2d1f7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc457016352c9443b6633e7dc1fd2d1f7)): ?>
<?php $component = $__componentOriginalc457016352c9443b6633e7dc1fd2d1f7; ?>
<?php unset($__componentOriginalc457016352c9443b6633e7dc1fd2d1f7); ?>
<?php endif; ?>

    <!-- CTA Section -->

    <?php if (isset($component)) { $__componentOriginala649cfbd6b1ff6fb80672d9879217508 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala649cfbd6b1ff6fb80672d9879217508 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.cta','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('cta'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala649cfbd6b1ff6fb80672d9879217508)): ?>
<?php $attributes = $__attributesOriginala649cfbd6b1ff6fb80672d9879217508; ?>
<?php unset($__attributesOriginala649cfbd6b1ff6fb80672d9879217508); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala649cfbd6b1ff6fb80672d9879217508)): ?>
<?php $component = $__componentOriginala649cfbd6b1ff6fb80672d9879217508; ?>
<?php unset($__componentOriginala649cfbd6b1ff6fb80672d9879217508); ?>
<?php endif; ?>

    <!-- Footer -->
    <?php if (isset($component)) { $__componentOriginal8a8716efb3c62a45938aca52e78e0322 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a8716efb3c62a45938aca52e78e0322 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $attributes = $__attributesOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $component = $__componentOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__componentOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>

    <!-- WhatsApp Floating Button -->
    <?php if (isset($component)) { $__componentOriginal52d409fc1fa687ab461fb439e195b906 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal52d409fc1fa687ab461fb439e195b906 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.whatsapp-float','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('whatsapp-float'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal52d409fc1fa687ab461fb439e195b906)): ?>
<?php $attributes = $__attributesOriginal52d409fc1fa687ab461fb439e195b906; ?>
<?php unset($__attributesOriginal52d409fc1fa687ab461fb439e195b906); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal52d409fc1fa687ab461fb439e195b906)): ?>
<?php $component = $__componentOriginal52d409fc1fa687ab461fb439e195b906; ?>
<?php unset($__componentOriginal52d409fc1fa687ab461fb439e195b906); ?>
<?php endif; ?>
</body>
</html><?php /**PATH C:\Users\phinics\Herd\rrinstitute\resources\views/welcome.blade.php ENDPATH**/ ?>