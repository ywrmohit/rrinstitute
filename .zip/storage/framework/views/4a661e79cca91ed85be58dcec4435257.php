<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web Development Course (MERN & Laravel) - RR Institute</title>
    <meta name="description" content="Become a Full Stack Web Developer. Choose between MERN Stack (MongoDB, Express, React, Node) or PHP Laravel. Build dynamic websites and web apps.">
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="bg-gray-50 text-gray-800 antialiased font-sans">

    <?php if (isset($component)) { $__componentOriginal0c8ef625e8265a4afd8570b9540f6b64 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0c8ef625e8265a4afd8570b9540f6b64 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.announcement-bar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('announcement-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0c8ef625e8265a4afd8570b9540f6b64)): ?>
<?php $attributes = $__attributesOriginal0c8ef625e8265a4afd8570b9540f6b64; ?>
<?php unset($__attributesOriginal0c8ef625e8265a4afd8570b9540f6b64); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0c8ef625e8265a4afd8570b9540f6b64)): ?>
<?php $component = $__componentOriginal0c8ef625e8265a4afd8570b9540f6b64; ?>
<?php unset($__componentOriginal0c8ef625e8265a4afd8570b9540f6b64); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginala591787d01fe92c5706972626cdf7231 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala591787d01fe92c5706972626cdf7231 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala591787d01fe92c5706972626cdf7231)): ?>
<?php $attributes = $__attributesOriginala591787d01fe92c5706972626cdf7231; ?>
<?php unset($__attributesOriginala591787d01fe92c5706972626cdf7231); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala591787d01fe92c5706972626cdf7231)): ?>
<?php $component = $__componentOriginala591787d01fe92c5706972626cdf7231; ?>
<?php unset($__componentOriginala591787d01fe92c5706972626cdf7231); ?>
<?php endif; ?>

    <!-- Hero Section -->
    <div class="relative pt-32 pb-20 md:pt-40 md:pb-32 bg-purple-50 overflow-hidden">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div class="text-center max-w-3xl mx-auto">
                <span class="inline-block py-1 px-3 rounded-full bg-purple-100 text-purple-700 text-sm font-semibold mb-6 tracking-wide uppercase">High Demand Career</span>
                <h1 class="text-4xl md:text-5xl font-bold text-gray-900 mb-6 leading-tight">
                    Full Stack <span class="text-purple-600">Web Development</span>
                </h1>
                <p class="text-lg text-gray-600 mb-8 leading-relaxed">
                    Build the web of tomorrow. Choose your path: The modern JavaScript-based MERN Stack or the robust PHP Laravel Framework.
                </p>
            </div>
        </div>
    </div>

    <!-- Course Overview -->
    <section class="py-16 bg-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
                <div class="order-2 md:order-1">
                    <h2 class="text-3xl font-bold text-gray-900 mb-6">Course Overview</h2>
                    <p class="text-gray-600 mb-6 leading-relaxed">
                        Our Web Development course is designed to make you industry-ready. We offer two specialized tracks so you can choose the technology stack that suits your career goals. Whether you want to build single-page applications with React or robust enterprise apps with Laravel, we have you covered.
                    </p>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div class="bg-purple-50 p-4 rounded-xl border border-purple-100">
                            <h3 class="font-bold text-purple-700 mb-2">MERN Stack</h3>
                            <p class="text-sm text-gray-600">MongoDB, Express.js, React.js, Node.js. Best for modern, scalable web apps.</p>
                        </div>
                        <div class="bg-red-50 p-4 rounded-xl border border-red-100">
                            <h3 class="font-bold text-red-700 mb-2">PHP Laravel</h3>
                            <p class="text-sm text-gray-600">PHP, Laravel, MySQL. Best for rapid development and enterprise solutions.</p>
                        </div>
                    </div>
                </div>
                <div class="order-1 md:order-2">
                    <img src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=800&q=80" alt="Web Development" class="rounded-2xl shadow-xl">
                </div>
            </div>
        </div>
    </section>

    <!-- Curriculum -->
    <section class="py-16 bg-gray-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 class="text-3xl font-bold text-gray-900 mb-12 text-center">Course Curriculum</h2>
            
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <!-- Common Foundation -->
                <div class="lg:col-span-2 bg-white p-8 rounded-2xl shadow-sm border border-gray-100 mb-4">
                    <h3 class="text-2xl font-bold text-gray-900 mb-4">Foundation (Common for Both)</h3>
                    <ul class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <li class="flex items-center gap-2 text-gray-700">
                            <svg class="w-5 h-5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                            HTML5 & Semantic Web
                        </li>
                        <li class="flex items-center gap-2 text-gray-700">
                            <svg class="w-5 h-5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                            CSS3, Flexbox & Grid
                        </li>
                        <li class="flex items-center gap-2 text-gray-700">
                            <svg class="w-5 h-5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                            JavaScript (ES6+)
                        </li>
                        <li class="flex items-center gap-2 text-gray-700">
                            <svg class="w-5 h-5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                            Responsive Design & Bootstrap/Tailwind
                        </li>
                        <li class="flex items-center gap-2 text-gray-700">
                            <svg class="w-5 h-5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                            Git & GitHub
                        </li>
                    </ul>
                </div>

                <!-- MERN Track -->
                <div class="bg-white p-8 rounded-2xl shadow-sm border-t-4 border-purple-500">
                    <h3 class="text-2xl font-bold text-purple-700 mb-6">Track 1: MERN Stack</h3>
                    <div class="space-y-6">
                        <div>
                            <h4 class="font-bold text-gray-900 mb-2">React.js (Frontend)</h4>
                            <p class="text-sm text-gray-600">Components, Props, State, Hooks, Context API, Redux, React Router.</p>
                        </div>
                        <div>
                            <h4 class="font-bold text-gray-900 mb-2">Node.js & Express (Backend)</h4>
                            <p class="text-sm text-gray-600">RESTful APIs, Middleware, Authentication (JWT), File Uploads.</p>
                        </div>
                        <div>
                            <h4 class="font-bold text-gray-900 mb-2">MongoDB (Database)</h4>
                            <p class="text-sm text-gray-600">NoSQL Database design, Mongoose ODM, CRUD operations, Aggregation.</p>
                        </div>
                    </div>
                </div>

                <!-- Laravel Track -->
                <div class="bg-white p-8 rounded-2xl shadow-sm border-t-4 border-red-500">
                    <h3 class="text-2xl font-bold text-red-700 mb-6">Track 2: PHP Laravel</h3>
                    <div class="space-y-6">
                        <div>
                            <h4 class="font-bold text-gray-900 mb-2">Advanced PHP</h4>
                            <p class="text-sm text-gray-600">OOP in PHP, Namespaces, Composer, Error Handling.</p>
                        </div>
                        <div>
                            <h4 class="font-bold text-gray-900 mb-2">Laravel Framework</h4>
                            <p class="text-sm text-gray-600">MVC Architecture, Routing, Controllers, Blade Templating, Eloquent ORM.</p>
                        </div>
                        <div>
                            <h4 class="font-bold text-gray-900 mb-2">MySQL (Database)</h4>
                            <p class="text-sm text-gray-600">Relational Database design, SQL Queries, Joins, Migrations.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA -->
    <section class="py-20 bg-purple-600 text-white text-center">
        <div class="max-w-4xl mx-auto px-4">
            <h2 class="text-3xl font-bold mb-6">Build Your Career in Tech</h2>
            <p class="text-xl mb-8 text-purple-100">Choose your stack and start building real-world applications today.</p>
            <a href="<?php echo e(route('contact')); ?>" class="inline-block bg-white text-purple-700 px-8 py-3 rounded-full font-bold hover:bg-gray-100 transition-colors">Enroll Now</a>
        </div>
    </section>

    <?php if (isset($component)) { $__componentOriginal8a8716efb3c62a45938aca52e78e0322 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a8716efb3c62a45938aca52e78e0322 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $attributes = $__attributesOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $component = $__componentOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__componentOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal52d409fc1fa687ab461fb439e195b906 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal52d409fc1fa687ab461fb439e195b906 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.whatsapp-float','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('whatsapp-float'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal52d409fc1fa687ab461fb439e195b906)): ?>
<?php $attributes = $__attributesOriginal52d409fc1fa687ab461fb439e195b906; ?>
<?php unset($__attributesOriginal52d409fc1fa687ab461fb439e195b906); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal52d409fc1fa687ab461fb439e195b906)): ?>
<?php $component = $__componentOriginal52d409fc1fa687ab461fb439e195b906; ?>
<?php unset($__componentOriginal52d409fc1fa687ab461fb439e195b906); ?>
<?php endif; ?>
</body>
</html>
<?php /**PATH C:\Users\phinics\Herd\rrinstitute\resources\views\courses\web-development.blade.php ENDPATH**/ ?>